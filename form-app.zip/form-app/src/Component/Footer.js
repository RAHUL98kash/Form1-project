import React from 'react'


export const Footer = () => { 
    return (
        <footer className="p-3 mb-2 bg-success text-white">
            <p className="text-center">
            Copyright &copy; MyDataSystem.com
            </p>
        </footer>
    )
}
